﻿Module Module1

    Sub Main()
        Dim a1 As Konst = New Konst(3)
        Dim a2 As Konst = New Konst(4)
        Dim a3 As Konst = New Konst(5)

        Dim n1 As Neg = New Neg()

        Dim s1 As Sum = New Sum()
        Dim p1 As Prod = New Prod()

        s1.left = a1
        p1.left = a2
        p1.right = a3
        s1.right = p1
        n1.right = s1

        Console.WriteLine("The result is: " & n1.eval().getValue.ToString)
        Console.ReadLine()
    End Sub

End Module
