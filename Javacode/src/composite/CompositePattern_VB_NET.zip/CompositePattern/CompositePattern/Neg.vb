﻿Public Class Neg
    Implements ArithmeticExpr
    Public right As ArithmeticExpr
    Private left As ArithmeticExpr = New Konst(-1)

    Public Function eval() As Konst Implements ArithmeticExpr.eval
        Console.WriteLine("*")
        Return New Konst((left.eval.getValue) * (right.eval.getValue))
    End Function
End Class
