﻿Public Class Sum
    Implements ArithmeticExpr
    Public left As ArithmeticExpr
    Public right As ArithmeticExpr

    Public Function eval() As Konst Implements ArithmeticExpr.eval
        Console.WriteLine("+")
        Return New Konst((left.eval().getValue()) + (right.eval().getValue()))
    End Function
End Class
