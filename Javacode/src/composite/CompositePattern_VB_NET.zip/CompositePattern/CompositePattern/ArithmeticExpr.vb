﻿Public Interface ArithmeticExpr
    Function eval() As Konst
End Interface
