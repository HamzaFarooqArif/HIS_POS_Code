﻿Public Class Konst
    Implements ArithmeticExpr
    Private value As Integer = 0

    Public Function getValue() As Integer
        Return value
    End Function

    Public Function eval() As Konst Implements ArithmeticExpr.eval
        Console.WriteLine(CStr(value))
        Return Me
    End Function

    Public Sub New(ByVal _value As Integer)
        value = _value
    End Sub

End Class
